<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Apply for new membership</name>
   <tag></tag>
   <elementGuidId>3eede6da-48e2-4b19-a814-776e979ad85e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Apply for new membership')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li:nth-of-type(3) > a.dropdown-item.ff-inter</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7a8de6e7-cda4-4445-a2db-bf0e6845d8d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>44ca4453-ee4c-4c7b-b465-7a4b580081de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/membership/apply</value>
      <webElementGuid>1e642db7-bc30-49eb-9997-655c3b06bb2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Apply for new membership </value>
      <webElementGuid>a720ff73-4139-4eef-80ee-907e87d1175e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[3]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>f83f5f11-5c16-4db7-856e-4a6b5fde9d4e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Apply for new membership')]</value>
      <webElementGuid>13124146-0c51-4db1-b0eb-589a55020c71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='How to Become a Member'])[1]/following::a[1]</value>
      <webElementGuid>f90060ff-a011-401f-ae1e-0b8db8fbf055</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Benefits Of Membership'])[1]/following::a[2]</value>
      <webElementGuid>39982a6a-18a6-4875-9961-151fd81203c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQ'])[1]/preceding::a[1]</value>
      <webElementGuid>ea569d4a-4628-4836-8762-93e0c25c6b2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/preceding::a[2]</value>
      <webElementGuid>9d2ce2e6-8eb7-4cb9-837a-5ebcd3625e88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Apply for new membership']/parent::*</value>
      <webElementGuid>8644fa0f-8acd-40f4-bcf7-9e9994d30da0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/membership/apply')]</value>
      <webElementGuid>0d9704ef-1eac-4513-8cfe-4a1111f4dfb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li[3]/a</value>
      <webElementGuid>bf0af1a6-67e8-4e98-8d33-ac052562e25a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/membership/apply' and (text() = 'Apply for new membership ' or . = 'Apply for new membership ')]</value>
      <webElementGuid>ed2565f3-f5ce-4ef4-93d1-caef64f8e9be</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
