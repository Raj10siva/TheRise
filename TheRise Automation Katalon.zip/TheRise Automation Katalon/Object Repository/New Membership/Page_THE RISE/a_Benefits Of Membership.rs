<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Benefits Of Membership</name>
   <tag></tag>
   <elementGuidId>fef47416-183a-42c6-b6ac-af0639dc5c02</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Benefits Of Membership')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li > a.dropdown-item.ff-inter</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>be3e5822-98c1-4fe4-afbe-e3df2789dae6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>635a06cc-d025-4c32-a208-cea49947eae8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/membership/benefits</value>
      <webElementGuid>b236ce38-495b-4b74-b5e5-58f09bab9254</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Benefits Of Membership</value>
      <webElementGuid>4cea1785-d0ed-41cf-aadd-07ce24ef4894</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[1]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>cd4c6b9f-16f2-4611-b364-7e249002fe5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Benefits Of Membership')]</value>
      <webElementGuid>0aff7dcc-68aa-49f8-b461-0f2a0096ccc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[2]</value>
      <webElementGuid>7e812d3b-24eb-40a2-9cc6-00aa0b324086</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gulf Summit'])[1]/following::a[3]</value>
      <webElementGuid>8ec9cc9e-086c-49bc-a928-a2e08574911d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='How to Become a Member'])[1]/preceding::a[1]</value>
      <webElementGuid>eff98b5f-7ef9-4495-87ce-70c552f9fb75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply for new membership'])[1]/preceding::a[2]</value>
      <webElementGuid>4d31bb23-f0b5-42a6-acfa-ab6e06f07cf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Benefits Of Membership']/parent::*</value>
      <webElementGuid>418ac292-241d-4e42-8e6e-b528dd26d570</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/membership/benefits')]</value>
      <webElementGuid>c82ed6e0-98c6-4e8f-8637-d4c8679d28c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li/a</value>
      <webElementGuid>76621fba-74ea-42eb-9f11-1e0fa9e753ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/membership/benefits' and (text() = 'Benefits Of Membership' or . = 'Benefits Of Membership')]</value>
      <webElementGuid>47e64a49-988b-49b0-a3eb-5cfc1c974b7b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
