<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Malasiya Summit</name>
   <tag></tag>
   <elementGuidId>aacb07e0-cc60-4af5-a925-a7f42235fba6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li > a.dropdown-item.ff-inter</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Malasiya Summit')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a0c2462a-1416-43ab-8374-b104b662ba26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>1a3d3f03-a0e0-4a4a-ae4f-a242ca2c1606</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/summit/malaysia</value>
      <webElementGuid>d8e08711-460e-4c3d-a1b8-175799ef0ee1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Malasiya Summit</value>
      <webElementGuid>4d533a1d-aca9-4027-bb03-b48ac1a8c666</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[1]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>2b3d21ab-0d69-4228-a1f6-d0008e1d8a37</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Malasiya Summit')]</value>
      <webElementGuid>20063700-2c35-4453-a25e-f4fea9cd7ec4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T-one'])[1]/following::a[2]</value>
      <webElementGuid>075d2c1b-27dd-40a2-ba1b-7e0c10ac2176</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Impact'])[1]/following::a[3]</value>
      <webElementGuid>42104576-e426-4352-a70a-dbea0cc37b08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Davos Summit'])[1]/preceding::a[1]</value>
      <webElementGuid>edbef311-d723-462c-98ce-7b63bedfc713</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gulf Summit'])[1]/preceding::a[2]</value>
      <webElementGuid>51e51dfe-a94d-4929-afd0-aa28599e6d15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Malasiya Summit']/parent::*</value>
      <webElementGuid>22b90161-decd-4867-907a-021f65c196a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/summit/malaysia')]</value>
      <webElementGuid>85f95655-8868-418d-b179-465ae42eb60b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li/a</value>
      <webElementGuid>ec4b1f96-0573-4f21-a023-780f57a72085</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/summit/malaysia' and (text() = 'Malasiya Summit' or . = 'Malasiya Summit')]</value>
      <webElementGuid>603e2b78-5c69-4b1b-890b-314c21c20d88</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
