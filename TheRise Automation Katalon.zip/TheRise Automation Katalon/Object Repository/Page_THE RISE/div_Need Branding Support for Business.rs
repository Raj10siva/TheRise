<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Need Branding Support for Business</name>
   <tag></tag>
   <elementGuidId>9584bc83-6534-4ae6-aa94-2a333feafada</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sume']/div[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8b2cca85-940d-4fcc-8f50-c9c33e2f78dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-12 col-form-label</value>
      <webElementGuid>61cb9d5f-1e27-4dfa-971e-35e6d9fcb33a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    
                                    
                                      Need Branding Support for Business
  
                                    
                                  </value>
      <webElementGuid>d4e06307-ba71-4550-8380-aff5cc6204db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sume&quot;)/div[@class=&quot;col-sm-12 col-form-label&quot;]</value>
      <webElementGuid>892e63c9-db52-43e2-9683-000e24d36651</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sume']/div[6]</value>
      <webElementGuid>46530484-a6a6-4e87-8fc6-9fb31eddc32b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Seeking Funding &amp; Investments'])[1]/following::div[1]</value>
      <webElementGuid>a3b99cdf-7e59-47cb-addc-c331597ddc29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[14]/div[6]</value>
      <webElementGuid>75fe7cd5-f6f6-40f5-bd19-8306b9fd7e5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                    
                                    
                                      Need Branding Support for Business
  
                                    
                                  ' or . = '
                                    
                                    
                                      Need Branding Support for Business
  
                                    
                                  ')]</value>
      <webElementGuid>5dbef827-566d-4f9b-8d19-da5eeb4230da</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
