<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Seeking Funding  Investments</name>
   <tag></tag>
   <elementGuidId>d20ec37b-1a3d-460a-834b-6a1d2c65363b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sume']/div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d5849cc1-a73f-4d83-a03a-de1f37e338fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-12 col-form-label</value>
      <webElementGuid>58bfb960-60a9-48a3-95d2-368e2ef25b40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    
                                    
                                      Seeking Funding &amp; Investments
  
                                    
                                  </value>
      <webElementGuid>1ba3336a-e163-4ca0-bc03-15195046dbe5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sume&quot;)/div[@class=&quot;col-sm-12 col-form-label&quot;]</value>
      <webElementGuid>6246b150-5d96-42f0-9dd3-ab6453e9bc65</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sume']/div[5]</value>
      <webElementGuid>304c5d78-b4ab-43b8-8a23-b3955484f731</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Need Branding Support for Business'])[1]/preceding::div[1]</value>
      <webElementGuid>77e0a4cd-1b58-46ac-ab03-a64e5f51689b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[14]/div[5]</value>
      <webElementGuid>1ddbaf90-eaa4-456f-8f95-1ccd7f62dc65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                    
                                    
                                      Seeking Funding &amp; Investments
  
                                    
                                  ' or . = '
                                    
                                    
                                      Seeking Funding &amp; Investments
  
                                    
                                  ')]</value>
      <webElementGuid>b44c5708-73a4-4dfa-93c5-01a4a8f184eb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
