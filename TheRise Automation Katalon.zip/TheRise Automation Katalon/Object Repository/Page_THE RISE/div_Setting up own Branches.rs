<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Setting up own Branches</name>
   <tag></tag>
   <elementGuidId>a2f46196-341e-45f2-a9d8-433f56e045bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sume']/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>64a42f2b-9317-41e2-88f7-cc001561e1fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-12 col-form-label</value>
      <webElementGuid>b55e31be-6f74-4dcd-acb2-926824afbfad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    
                                    
                                      Setting up own Branches
                                    
                                  </value>
      <webElementGuid>37bd9276-8352-4365-97ed-e0513e64d1d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sume&quot;)/div[@class=&quot;col-sm-12 col-form-label&quot;]</value>
      <webElementGuid>170be1ed-2b9d-4073-a64c-a8ccd7c20958</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sume']/div[2]</value>
      <webElementGuid>cd17c491-da01-4758-9d96-dfcaaaf4abce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Networking &amp; Making New Friends'])[1]/following::div[1]</value>
      <webElementGuid>32a62493-1287-4715-86de-e30e87aa8e41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[14]/div[2]</value>
      <webElementGuid>dcd1cbef-e8d0-4802-a68f-0b19feb30342</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                    
                                    
                                      Setting up own Branches
                                    
                                  ' or . = '
                                    
                                    
                                      Setting up own Branches
                                    
                                  ')]</value>
      <webElementGuid>ff129a7b-7af5-4b7d-98bb-d6f35f9eeb69</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
