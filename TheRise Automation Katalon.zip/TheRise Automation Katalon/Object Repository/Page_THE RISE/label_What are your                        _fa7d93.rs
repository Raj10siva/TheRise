<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_What are your                        _fa7d93</name>
   <tag></tag>
   <elementGuidId>325f0370-6bb0-43de-a03c-c00dea84258a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#sume > label.col-sm-12.col-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sume']/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>42e25c11-280f-4317-9226-97d214ca8537</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>exampleInputConfirmPassword2</value>
      <webElementGuid>63b4fb09-7300-4265-b82c-bf37651c12f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-12 col-form-label</value>
      <webElementGuid>c367e714-0ed9-47ba-899c-8788de680497</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>What are your
                                    expectations from the Summit?</value>
      <webElementGuid>83258771-bd48-4b76-981a-47a5bfc001f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sume&quot;)/label[@class=&quot;col-sm-12 col-form-label&quot;]</value>
      <webElementGuid>1ee0cb8e-4046-4d23-8c64-6613bb34f4e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sume']/label</value>
      <webElementGuid>21067739-d42f-478a-91a0-b96ec817d589</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Address'])[1]/following::label[2]</value>
      <webElementGuid>d8123968-5b46-41ae-952d-eda8ba0000f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Networking &amp; Making New Friends'])[1]/preceding::label[1]</value>
      <webElementGuid>4b5c66d6-1e99-4cbd-ae40-a1428f06d292</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setting up own Branches'])[1]/preceding::label[2]</value>
      <webElementGuid>66e476a2-eabd-483b-b143-33439658ef96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[14]/label</value>
      <webElementGuid>63e0f589-d237-4960-a168-52cfee4c83d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'What are your
                                    expectations from the Summit?' or . = 'What are your
                                    expectations from the Summit?')]</value>
      <webElementGuid>f16b4747-1748-435d-8ed8-5dc20c46077f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
