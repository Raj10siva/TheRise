<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select anyone                       _530868</name>
   <tag></tag>
   <elementGuidId>7a69364c-9509-4b18-b7e9-726ef956308e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#prounder</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='prounder']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>7c13c32b-db21-4ebc-8d73-6c5dd8f274f2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>3866d95c-a508-43e5-a2cb-055242fb0012</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>profession</value>
      <webElementGuid>394c6a44-cc26-4f9f-a515-dea5a51681e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>prounder</value>
      <webElementGuid>c5e818ee-418a-4997-ae74-22f6883047a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>
                                    if(document.getElementById('prounder').value=='Others')
                                    {document.getElementById('prounder-other').style.display='flex'
                                    
                                    }
                                    else 
                                  {  document.getElementById('prounder-other').style.display='none'
                                  
                                   
                                  }
                                    </value>
      <webElementGuid>afff3916-bce2-4439-bbb1-7d6916eabc00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                      Select anyone
  
                                      Auditor
                                      Lawyer
                                      Engineer
                                      Doctor
                                      Educationalist
                                      Others
                                    </value>
      <webElementGuid>3e1dd727-6ea9-489d-85a3-728ba967186c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;prounder&quot;)</value>
      <webElementGuid>aa6e1524-407e-4a30-a53b-78ba802f2ef5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='prounder']</value>
      <webElementGuid>10203783-c4f0-4e09-8cb7-bfedee45b3c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='iam']/div/select</value>
      <webElementGuid>eda3cd08-c0dd-4f89-b6e6-056b4d8c600a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='I am a'])[1]/following::select[1]</value>
      <webElementGuid>b2b44e2d-957e-4235-876d-ed3aea74454e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Others'])[3]/following::select[1]</value>
      <webElementGuid>7285badc-4eab-4247-a76b-1d8b617be74a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Others'])[5]/preceding::select[1]</value>
      <webElementGuid>64a70ed6-d998-4abd-abe1-05266378f924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/select</value>
      <webElementGuid>7822d4b7-0eab-4a97-bed2-1f9a12a196e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'profession' and @id = 'prounder' and (text() = '
                                      Select anyone
  
                                      Auditor
                                      Lawyer
                                      Engineer
                                      Doctor
                                      Educationalist
                                      Others
                                    ' or . = '
                                      Select anyone
  
                                      Auditor
                                      Lawyer
                                      Engineer
                                      Doctor
                                      Educationalist
                                      Others
                                    ')]</value>
      <webElementGuid>f31b08b5-eaf9-453e-9c8c-47993ca110c8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
