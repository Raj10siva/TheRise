<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Tamil Enthusiasts                   _b1502c</name>
   <tag></tag>
   <elementGuidId>c5136538-9fc1-461b-b16b-fce9e4e9d692</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#pro</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='pro']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>0ca0d9c0-fda8-40eb-9025-280b296dd662</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>f33d55c4-367f-49ee-9774-25d3b2201775</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>occ</value>
      <webElementGuid>771661d3-c9b4-48f7-8fed-6cb5ea073eed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>pro</value>
      <webElementGuid>90ec0a9a-9bb1-4ed5-969d-d895de2eafde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>
                                    if(document.getElementById('pro').value=='Others')
                                    {document.getElementById('pro-other').style.display='flex'
                                      document.getElementById('iam').style.display='none'
                                      document.getElementById('category').style.display='none'
                                      
                                     
                                    }
                                    else  if(document.getElementById('pro').value=='Professionals')
                                  {  document.getElementById('pro-other').style.display='none'
                                    document.getElementById('iam').style.display='flex'
                                    document.getElementById('category').style.display='none'
                                    
                                  
                                  }
                                  else  if(document.getElementById('pro').value=='Entrepreneur')
                                  {  document.getElementById('pro-other').style.display='none';
                                    document.getElementById('iam').style.display='none';
                                    document.getElementById('category').style.display='block';
                                    
                               
                                    
  
                                  }
                                else  if(document.getElementById('pro').value=='Tamil Enthusiasts')
                                  {  document.getElementById('pro-other').style.display='none'
                                    document.getElementById('iam').style.display='none'
                                    document.getElementById('category').style.display='none'
                                   document.getElementById('sume').style.display='block'
                                   
                                     
  
                                  }
  
                                  else{
                                    document.getElementById('pro-other').style.display='none'
                                    document.getElementById('iam').style.display='none'
                                    document.getElementById('category').style.display='none'
                                  
                                   
                                  }
                                     document.getElementById('prounder-other').style.display='none'
                                   
                                    </value>
      <webElementGuid>85718528-1a0a-4732-96e3-e6dbea5e2cf0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                       Tamil Enthusiasts
  
                                      Entrepreneur
                                      Professionals
                                     
                                      Others
                                    </value>
      <webElementGuid>68e47cd8-b37b-40ea-afec-d98bdce4da52</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pro&quot;)</value>
      <webElementGuid>48fefd9b-ce00-4466-bce6-c6e2b3558808</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='pro']</value>
      <webElementGuid>c7cbea1f-f8d0-42be-bcf3-f8268069767f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='registration_form']/div[8]/div/select</value>
      <webElementGuid>d1492165-7a66-4c5c-ab39-1c571c2c22c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[7]/following::select[1]</value>
      <webElementGuid>f5381aa0-9480-4585-94cb-6b88e0fb4e48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Others'])[3]/preceding::select[1]</value>
      <webElementGuid>c2dedbac-188a-4d2f-9b77-6468ecd8ccde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='I am a'])[1]/preceding::select[1]</value>
      <webElementGuid>df2d5a9c-eea8-480e-81f3-d852d8633087</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>57f1a6a7-1db0-4aca-a9d3-a1c9fea575c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'occ' and @id = 'pro' and (text() = '
                                       Tamil Enthusiasts
  
                                      Entrepreneur
                                      Professionals
                                     
                                      Others
                                    ' or . = '
                                       Tamil Enthusiasts
  
                                      Entrepreneur
                                      Professionals
                                     
                                      Others
                                    ')]</value>
      <webElementGuid>5cb0f63a-89c3-4792-9c16-db150056a4e0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
