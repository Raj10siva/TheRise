<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Register now</name>
   <tag></tag>
   <elementGuidId>3b5b02c0-49bd-4239-a2e0-55987d4f36e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.fw-medium.text-black</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f695917b-34da-498a-ada8-988b2dcfe273</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fw-medium text-black</value>
      <webElementGuid>2827afeb-caaf-449b-a2f3-abf69b58137c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Register now </value>
      <webElementGuid>e7f7d9c5-79ff-4951-bea2-a1d6f46fde10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/section[@class=&quot;the-rice-wrapper&quot;]/section[@class=&quot;cont-wrapper&quot;]/div[@class=&quot;bg-grdient-blue&quot;]/div[@class=&quot;members-block d-flex justify-content-evenly&quot;]/div[@class=&quot;member-cont aos-init aos-animate&quot;]/div[@class=&quot;btn-wrpr justify-content-center&quot;]/a[@class=&quot;trice-btn-primary bg-yellow&quot;]/span[@class=&quot;fw-medium text-black&quot;]</value>
      <webElementGuid>98c03bf0-cd06-40d1-8a67-ddf6670444ee</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[1]/following::span[1]</value>
      <webElementGuid>26cf43af-d304-4032-ade1-d74f471b1fd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='www.tamilrise.org'])[1]/following::span[2]</value>
      <webElementGuid>217f62df-5c46-4bcb-9fca-7748dbcc05a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[2]/preceding::span[1]</value>
      <webElementGuid>45785542-9195-477f-8b54-0c2d05fa13b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register now'])[2]/preceding::span[2]</value>
      <webElementGuid>150896aa-36f8-4ea0-8a0c-ca267319d2ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Register now']/parent::*</value>
      <webElementGuid>adffd64e-1332-479b-9eea-24984150e5c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/span</value>
      <webElementGuid>c2642b48-8b86-4d1e-8d80-bdc9b4b1d3d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Register now ' or . = ' Register now ')]</value>
      <webElementGuid>72233d6b-02d8-478f-ab63-4b3830461da6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
