<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Continue and pay</name>
   <tag></tag>
   <elementGuidId>0156d532-8531-421c-b0e9-919e653d4e9d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.btn.svelte-1bvu3zp</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='overlay']/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5613346f-701b-4d45-8648-6cee55db6536</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn svelte-1bvu3zp</value>
      <webElementGuid>0833de48-4fd5-4b4a-a8c8-1836ea37dbce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Continue and pay</value>
      <webElementGuid>4bf1df08-ce35-4fac-b29d-ba092990bf71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;overlay&quot;)/div[@class=&quot;svelte-6v30lc&quot;]/div[@class=&quot;fee-bearer svelte-1bvu3zp checkout-redesign&quot;]/div[@class=&quot;btn svelte-1bvu3zp&quot;]</value>
      <webElementGuid>f7faf153-7417-427a-8fb5-1d0427e8a831</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Payment gateway/Page_THE RISE/iframe_Test Mode_razorpay-checkout-frame</value>
      <webElementGuid>87b0db55-bf22-4fee-91e8-cd0a4fd3f881</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='overlay']/div/div/div[2]</value>
      <webElementGuid>d582e4e3-ecb1-4c23-98ba-7e7c07d522ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹ 20,472'])[1]/following::div[1]</value>
      <webElementGuid>c9b30b33-5a47-41d1-8a75-afb3b8f79577</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Charges'])[1]/following::div[2]</value>
      <webElementGuid>0ca36e15-423f-4326-9872-b40887f08afb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/preceding::div[1]</value>
      <webElementGuid>89656d45-9c11-4f72-b32c-5e8016357327</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Retry'])[1]/preceding::div[8]</value>
      <webElementGuid>bbda276f-dace-470d-a2b7-e4edcc0e6aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Continue and pay']/parent::*</value>
      <webElementGuid>c2add3ed-3cbd-4152-8804-71dc4c6d48c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[2]</value>
      <webElementGuid>174c916d-e6bd-4bbc-a19b-621e5b621793</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Continue and pay' or . = 'Continue and pay')]</value>
      <webElementGuid>6a307fdf-f6e0-43b2-b300-5719cfbc4d79</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
