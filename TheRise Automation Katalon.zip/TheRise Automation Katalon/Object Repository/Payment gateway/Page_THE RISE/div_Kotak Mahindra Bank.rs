<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Kotak Mahindra Bank</name>
   <tag></tag>
   <elementGuidId>964efa53-3439-40fc-8de0-088a37da2595</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='form-paylater']/div/div/div/div/div[2]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>21e71d43-a43f-44d1-95f3-001fde61ec14</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kotak Mahindra Bank </value>
      <webElementGuid>0a3c3591-78d6-4cd2-a1d0-f901253262f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;form-paylater&quot;)/div[@class=&quot;paylater-container svelte-vrseyb&quot;]/div[@class=&quot;paylater-wrapper svelte-vrseyb screen-one-cc&quot;]/div[1]/div[@class=&quot;options paylater-section svelte-vrseyb&quot;]/div[@class=&quot;option next-option&quot;]/div[@class=&quot;option-title svelte-q5r5wk&quot;]/div[1]</value>
      <webElementGuid>2abe78e4-fb40-4b33-9ddf-67ca09e54624</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Payment gateway/Page_THE RISE/iframe_Test Mode_razorpay-checkout-frame</value>
      <webElementGuid>c0c21e13-c5eb-4b68-92e7-537a47ccf944</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='form-paylater']/div/div/div/div/div[2]/div[2]/div</value>
      <webElementGuid>156e56b3-f11a-438d-84b2-3d7e333c664f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ePayLater'])[1]/following::div[4]</value>
      <webElementGuid>23645933-c5e4-4ddf-8963-b776ff6321d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select an option'])[1]/following::div[9]</value>
      <webElementGuid>8c83e49f-76f6-4daa-bf11-43a5315340ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Simpl'])[1]/preceding::div[2]</value>
      <webElementGuid>010efbfb-c487-4f45-b335-2487556f2d3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not eligible'])[1]/preceding::div[3]</value>
      <webElementGuid>906a8ff8-f5f2-4626-bc87-e94d275d98a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kotak Mahindra Bank']/parent::*</value>
      <webElementGuid>d07aff43-2c6c-4e51-8fd6-c94c15ec1df7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]/div[2]/div</value>
      <webElementGuid>47bef06a-55d3-494d-9e96-a32d4a9c4f18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Kotak Mahindra Bank ' or . = 'Kotak Mahindra Bank ')]</value>
      <webElementGuid>f8150c47-a1f3-4c28-bdf0-aed5e592b936</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
