<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Malasiya Summit</name>
   <tag></tag>
   <elementGuidId>b3ed3232-a929-4118-80e7-1424d275e82a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li > a.dropdown-item.ff-inter</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Malasiya Summit')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>543d49a2-45b7-4030-9010-dde4fe968fd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>9e2b535b-d735-4afb-9add-a6f85a39be87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/summit/malaysia</value>
      <webElementGuid>0d361dca-ce09-4417-91fb-2087a5de98cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Malasiya Summit</value>
      <webElementGuid>c9fd44cd-2719-4bea-9aa2-9169494844f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[1]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>41f3361d-c547-49c6-b6c5-7384db50f7c8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Malasiya Summit')]</value>
      <webElementGuid>70a39049-9004-4b01-8588-8e57460a5c64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T-one'])[1]/following::a[2]</value>
      <webElementGuid>56196189-b642-4842-809b-1d6882f9096b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Impact'])[1]/following::a[3]</value>
      <webElementGuid>aad23ad9-b13d-4527-a680-c64df39edcf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Davos Summit'])[1]/preceding::a[1]</value>
      <webElementGuid>29640d64-b1de-4f55-b330-c50d152f5a3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gulf Summit'])[1]/preceding::a[2]</value>
      <webElementGuid>8163d314-51d6-477a-b1ac-65e178ca378c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Malasiya Summit']/parent::*</value>
      <webElementGuid>ce410259-b35b-4b61-bae6-e8f012520e88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/summit/malaysia')]</value>
      <webElementGuid>3af98ce4-fa30-4bb4-b740-745776a193dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li/a</value>
      <webElementGuid>97841719-01f7-400b-893c-590345f97de0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/summit/malaysia' and (text() = 'Malasiya Summit' or . = 'Malasiya Summit')]</value>
      <webElementGuid>3aa3a6a8-574f-4eeb-ba65-1827eda6ad28</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
