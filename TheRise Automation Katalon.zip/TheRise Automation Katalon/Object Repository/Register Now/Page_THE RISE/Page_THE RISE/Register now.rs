<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Register now</name>
   <tag></tag>
   <elementGuidId>842f3aed-0ad4-4e3d-a51b-287a5f63ac14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.fw-medium.text-black</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c3e57b82-d357-45af-8e1c-10cb4fc7de8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fw-medium text-black</value>
      <webElementGuid>29372e7f-4fb0-4cfc-b5a5-1e8da54f87c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Register now </value>
      <webElementGuid>da89f6c5-6048-4f87-aa5d-90eddebbe49d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/section[@class=&quot;cont-wrapper&quot;]/div[@class=&quot;bg-grdient-blue&quot;]/div[@class=&quot;members-block d-flex justify-content-evenly&quot;]/div[@class=&quot;member-cont aos-init aos-animate&quot;]/div[@class=&quot;btn-wrpr justify-content-center&quot;]/a[@class=&quot;trice-btn-primary bg-yellow&quot;]/span[@class=&quot;fw-medium text-black&quot;]</value>
      <webElementGuid>60831e2c-1ee0-42d9-a529-14442beb37bd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[1]/following::span[1]</value>
      <webElementGuid>26c2ef0f-a9a6-4168-89c7-1ad4a6a27449</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='www.tamilrise.org'])[1]/following::span[2]</value>
      <webElementGuid>e1413f53-1e64-4f96-96e6-263c387b0bc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[2]/preceding::span[1]</value>
      <webElementGuid>3e6ab73b-c409-4579-ba9a-487ec6e2f3ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register now'])[2]/preceding::span[2]</value>
      <webElementGuid>403943c6-dc34-4d83-84da-5e302e9013c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Register now']/parent::*</value>
      <webElementGuid>6d37dbb0-8a62-473e-99bb-d16cc99756d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/span</value>
      <webElementGuid>83aa18f4-4b06-4404-88ee-44527e492715</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Register now ' or . = ' Register now ')]</value>
      <webElementGuid>f4b32996-be47-4188-9b1a-daaedbefc489</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
