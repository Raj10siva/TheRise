<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Davos Summit</name>
   <tag></tag>
   <elementGuidId>7aa70824-5298-403c-800d-1982e7f59d01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Davos Summit')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li:nth-of-type(2) > a.dropdown-item.ff-inter</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b550a4af-4cea-48c2-8d7f-02d8551876b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>0ca2a64d-0002-41cf-b0e0-09403a7208f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/summit/davos</value>
      <webElementGuid>c79b82f3-30ba-4435-b6a8-9f1073a3981e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Davos Summit</value>
      <webElementGuid>b23ac605-dfe2-4dfb-96c2-7990c55a5433</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[2]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>fdd63733-09ba-4728-91d7-0d11afe1e9ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Davos Summit')]</value>
      <webElementGuid>0459ab10-200a-46b4-b633-e6231b86664a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Malasiya Summit'])[1]/following::a[1]</value>
      <webElementGuid>01c95c9c-4d47-4007-b081-57e80a0cc401</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T-one'])[1]/following::a[3]</value>
      <webElementGuid>e05ac015-bb6a-42dc-89d3-307b33dac582</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gulf Summit'])[1]/preceding::a[1]</value>
      <webElementGuid>cc951954-cae4-49c3-9c73-f066804a7ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/preceding::a[2]</value>
      <webElementGuid>13d0a616-3dc6-4119-b878-e6585b5e0a20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Davos Summit']/parent::*</value>
      <webElementGuid>24ff989b-72bb-4b39-a23a-b40925f42888</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/summit/davos')]</value>
      <webElementGuid>f5e3f401-8814-47e4-ad26-0287fa186bf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li[2]/a</value>
      <webElementGuid>bc2f1be0-5f11-476f-9393-7faade120a33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/summit/davos' and (text() = 'Davos Summit' or . = 'Davos Summit')]</value>
      <webElementGuid>fc3e7a0c-df35-4185-b9b4-f76e54df7521</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
