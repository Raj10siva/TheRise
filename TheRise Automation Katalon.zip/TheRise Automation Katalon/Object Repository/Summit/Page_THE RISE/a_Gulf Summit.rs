<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gulf Summit</name>
   <tag></tag>
   <elementGuidId>be40c881-ca2d-4cc6-bc36-3b678f535a61</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Gulf Summit')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(3) > a.dropdown-item.ff-inter</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>922d2ef8-f068-44f5-a050-74af8f0a690e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>7e78e40e-e753-4cfc-8376-f59adab8ad7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/summit/gulf</value>
      <webElementGuid>777044f4-a0cc-45ac-91c9-0d0457b3ba00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Gulf Summit</value>
      <webElementGuid>ccd4d593-a0ba-4b78-a3ba-72781f976794</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[3]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>e8fb9af6-2ed8-4430-849c-7c78da2a0946</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Gulf Summit')]</value>
      <webElementGuid>7d5a476a-f7b7-4149-b2bf-6a5b36afed29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Davos Summit'])[1]/following::a[1]</value>
      <webElementGuid>3f1f76b1-a7ee-4508-8486-223d5e17b1c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Malasiya Summit'])[1]/following::a[2]</value>
      <webElementGuid>3deb5df0-fc9d-4ea5-91d8-0654907e94c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/preceding::a[1]</value>
      <webElementGuid>761a454b-a81b-4d35-8194-6a413e285984</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Benefits Of Membership'])[1]/preceding::a[3]</value>
      <webElementGuid>d4d439aa-cb24-415c-b60a-8f6aaf08f057</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Gulf Summit']/parent::*</value>
      <webElementGuid>1c5e1894-1ba4-4388-81b2-af4762ddb8a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/summit/gulf')]</value>
      <webElementGuid>c09abca7-499c-4e25-ba48-1f35498cfdb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li[3]/a</value>
      <webElementGuid>3fbd3654-deae-495c-ae12-465ab8712189</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/summit/gulf' and (text() = 'Gulf Summit' or . = 'Gulf Summit')]</value>
      <webElementGuid>79964d02-b91b-41d0-b56e-33ab71b74ff8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
