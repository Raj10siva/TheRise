<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Malasiya Summit</name>
   <tag></tag>
   <elementGuidId>87c44867-4adc-4a45-a4e2-f01f10dab40e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Malasiya Summit')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.show > li > a.dropdown-item.ff-inter</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>edf3f0a9-1974-44d5-977c-e7f941614e8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item ff-inter</value>
      <webElementGuid>6d6a1cdc-4833-42ef-b9cc-08faef0b43e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://linessoftech.com/rise/summit/malaysia</value>
      <webElementGuid>ffd058f3-8837-48ef-bb57-e35a126f04ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Malasiya Summit</value>
      <webElementGuid>66ea5c99-168d-4a7e-bb66-45653861df56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;the-rice-wrapper&quot;]/header[1]/div[@class=&quot;nav-bar d-flex&quot;]/ul[@class=&quot;d-flex&quot;]/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;dropdown-menu show&quot;]/li[1]/a[@class=&quot;dropdown-item ff-inter&quot;]</value>
      <webElementGuid>af19b518-889b-44b0-ab85-32ad0affa21c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Malasiya Summit')]</value>
      <webElementGuid>94dbc49e-aece-4755-8cf9-3ebe87988ef0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T-one'])[1]/following::a[2]</value>
      <webElementGuid>eb20442d-3dc1-4af2-9025-41dbced8c601</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Impact'])[1]/following::a[3]</value>
      <webElementGuid>6d874df2-fff4-4623-9967-c02940cbf476</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Davos Summit'])[1]/preceding::a[1]</value>
      <webElementGuid>f766a852-d327-445e-a3a1-96df4ee13338</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gulf Summit'])[1]/preceding::a[2]</value>
      <webElementGuid>a441f5e1-99e1-40e1-acf2-84a2c6d0fa93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Malasiya Summit']/parent::*</value>
      <webElementGuid>bce9ce37-d9ee-4cd8-b727-c1ff383ac9e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://linessoftech.com/rise/summit/malaysia')]</value>
      <webElementGuid>b54fbec4-69d5-4691-a1b6-aa419a704f8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li/a</value>
      <webElementGuid>7a1be9d1-7bd5-4496-8a27-94b001c55dde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://linessoftech.com/rise/summit/malaysia' and (text() = 'Malasiya Summit' or . = 'Malasiya Summit')]</value>
      <webElementGuid>d1bf4c2e-bc57-4cce-ad79-7528f553c9a1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
