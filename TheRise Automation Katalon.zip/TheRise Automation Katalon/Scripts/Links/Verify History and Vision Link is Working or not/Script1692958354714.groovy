import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://linessoftech.com/rise/')

WebUI.click(findTestObject('Purpose/Page_THE RISE/a_Purpose'))

WebUI.click(findTestObject('Purpose/Page_THE RISE/a_History'))

String ExpectedURL = 'https://linessoftech.com/rise/purpose/history'

String ActualURL = WebUI.getUrl()

System.out.println(ActualURL)

	if (ActualURL == ExpectedURL) 
	{
    println('URL verification passed.')
	} 
	else 
	{
    println('URL verification failed.')
	}

println('Expected URL is: ' + ExpectedURL)

println('Actual URL is: ' + ActualURL)

WebUI.click(findTestObject('Purpose/Page_THE RISE/a_Purpose'))

WebUI.click(findTestObject('Purpose/Page_THE RISE/a_Vision'))

String ExpectedURL1 = 'https://linessoftech.com/rise/purpose/vision'

String ActualURL1 = WebUI.getUrl()

System.out.println(ActualURL1)

	if (ActualURL1 == ExpectedURL1) 
	{
    println('URL verification passed.')
	} 
	else 
	{
    println('URL verification failed.')
	}

println('Expected URL1 is: ' + ExpectedURL1)

println('Actual URL1 is: ' + ActualURL1)

WebUI.closeBrowser()

