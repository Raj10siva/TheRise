import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://linessoftech.com/rise/')

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_New Membership'))

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_Benefits Of Membership'))

String ExpectedURL1 = 'https://linessoftech.com/rise/membership/benefits'

String ActualURL1 = WebUI.getUrl()

if (ActualURL1 == ExpectedURL1) {
    println('URL verification passed.')
} else {
    println('URL verification failed.')
}

println('Expected1 URL is: ' + ExpectedURL1)

println('Actual1 URL is: ' + ActualURL1)

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_New Membership'))

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_How to Become a Member'))

String ExpectedURL2 = 'https://linessoftech.com/rise/membership/howtobecomemember'

String ActualURL2 = WebUI.getUrl()

if (ActualURL2 == ExpectedURL2) {
    println('URL verification passed.')
} else {
    println('URL verification failed.')
}

println('Expected2 URL is: ' + ExpectedURL2)

println('Actual2 URL is: ' + ActualURL2)

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_New Membership'))

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_Apply for new membership'))

String ExpectedURL3 = 'https://linessoftech.com/rise/membership/apply'

String ActualURL3 = WebUI.getUrl()

if (ActualURL3 == ExpectedURL3) {
    println('URL verification passed.')
} else {
    println('URL verification failed.')
}

println('Expected3 URL is: ' + ExpectedURL3)

println('Actual3 URL is: ' + ActualURL3)

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_New Membership'))

WebUI.click(findTestObject('New Membership/Page_THE RISE/a_FAQ'))

String ExpectedURL4 = 'https://linessoftech.com/rise/membership/faq'

String ActualURL4 = WebUI.getUrl()

if (ActualURL4 == ExpectedURL4) {
	println('URL verification passed.')
} else {
	println('URL verification failed.')
}

println('Expected3 URL is: ' + ExpectedURL4)

println('Actual4 URL is: ' + ActualURL4)

WebUI.closeBrowser()

