import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://linessoftech.com/rise/')

WebUI.click(findTestObject('Object Repository/Page_THE RISE/a_Summit'))

WebUI.click(findTestObject('Object Repository/Page_THE RISE/a_Malasiya Summit'))

WebUI.click(findTestObject('Object Repository/Page_THE RISE/span_Register now'))

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input__name'), 'Ragavan')

WebUI.click(findTestObject('Object Repository/Page_THE RISE/input__inlineRadioOptions'))

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input__wno (1)'), '8787899665')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input__email'), 'Ragu121@gmail.com')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input__city'), 'Chennai')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input__country'), 'India')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Tamil Enthusiasts                   _b1502c'), 
    'Tamil Enthusiasts', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Tamil Enthusiasts                   _b1502c'), 
    'Entrepreneur', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Tamil Enthusiasts                   _b1502c'), 
    'Professionals', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Tamil Enthusiasts                   _b1502c'), 
    'Others', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Tamil Enthusiasts                   _b1502c'), 
    'Professionals', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Auditor', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Lawyer', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Engineer', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Doctor', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Educationalist', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Others', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select anyone                       _530868'), 
    'Engineer', true)

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input_Name of the                          _a680fa'), 'Ragu SOftware private limited')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input_Your Designation_designation'), 'Software tester')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input_Company Address_company_address'), '101, Kovil Street, Thiru Nagar, chennai.')

WebUI.setText(findTestObject('Object Repository/Page_THE RISE/input_Business Website                     _0a8037'), 'https://www.raguinfotech.com/')

WebUI.click(findTestObject('Object Repository/Page_THE RISE/label_What are your                        _fa7d93'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    'M', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    'S', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    'L', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    'XL', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    '2XL', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    '3XL', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    '4XL', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_THE RISE/select_Select Size                         _d302b8'), 
    'L', true)

WebUI.click(findTestObject('Object Repository/Page_THE RISE/button_Make A                          Payment'))

WebUI.delay(10)

WebUI.closeBrowser()

